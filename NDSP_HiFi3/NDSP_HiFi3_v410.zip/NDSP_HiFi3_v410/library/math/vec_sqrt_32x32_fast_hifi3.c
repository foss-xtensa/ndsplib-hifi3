/* ------------------------------------------------------------------------ */
/* Copyright (c) 2021 by Cadence Design Systems, Inc. ALL RIGHTS RESERVED.  */
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence licensee.                                     */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library                                                 */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (C) 2009-2021 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
  NatureDSP Signal Processing Library. Math functions
    Square Root
    C code optimized for HiFi3
  IntegrIT, 2006-2018
*/
#include "scl_sqrt_table.h"
#include "common.h"
/* Signal Processing Library API. */
#include "NatureDSP_Signal_math.h"

/*-------------------------------------------------------------------------
  Square Root
  These routines calculate square root.
  NOTE: functions return 0x80000000 on negative argument for 32-bit outputs
  or 0x8000 for 16-bit outputs.
  Two versions of functions available: regular version (vec_sqrt16x16,
  vec_sqrt24x24, vec_sqrt32x32, vec_sqrt64x32) with arbitrary arguments and
  faster version (vec_sqrt24x24_fast, vec_sqrt32x32_fast) that apply some restrictions.

  Precision: 
  16x16  16-bit inputs, 16-bit output. Accuracy: 2LSB
  24x24  24-bit inputs, 24-bit output. Accuracy: (2.6e-7*y+1LSB)
  32x32  32-bit inputs, 32-bit output. Accuracy: (2.6e-7*y+1LSB)
  64x32  64-bit inputs, 32-bit output. Accuracy: 2LSB

  Input:
  x[N]  input data, Q15, Q31, Q63 
  N     length of vectors
  Output:
  y[N]  output data, Q15, Q31

  Restriction:
  Regular versions (vec_sqrt16x16, vec_sqrt24x24, vec_sqrt32x32, vec_sqrt64x32):
  x,y - should not overlap

  Faster versions (vec_sqrt24x24_fast, vec_sqrt32x32_fast):
  x,y - should not overlap
  x,y - aligned on 8-byte boundary
  N   - multiple of 2

  Scalar versions:
  ----------------
  return result, Q15, Q31
-------------------------------------------------------------------------*/
void vec_sqrt32x32_fast (int32_t * restrict y, const int32_t * restrict x, int N)
{
        ae_int32x2     * restrict py  = (      ae_int32x2   *)y;
  const ae_int32x2     * restrict px  = (const ae_int32x2   *)x;
  int         n, nsaa, nsab, idxa, idxb, shft_a, shft_b;
  ae_int32x2  vcw, vxw, vzw, viw, vxa, vxb, vxc, vxd, t0, t1, c1, c4;
  ae_f32x2    vxf, vzf, vcf;
  xtbool2     inf_ab,zero;
  if (N <= 0) return;
  vzw = AE_MOVI(0);
  c1 = AE_MOVI( ~1 );
  c4 = AE_MOVDA32X2( 0xFFFFFFF8,0xFFFFFFF8 );
  viw = AE_MOVDA32X2(MIN_INT32, MIN_INT32);

  /*algorithm*/
  //   f(x) = sqrt(x)  
  //   f(x) = f(xo) + f'(x0)*(x-x0)
  //   x-x0=dx
  //   x in range 0..1
  //   x0 in range 0.25..1
  NASSERT_ALIGN8(px);
  NASSERT_ALIGN8(py);
  ASSERT((N&1)==0);
  for (n=0; n<N; n+=2)
  {
    /*Load two input numbers */
    AE_L32X2_IP( vxb, px, 8 );
    vxa = AE_SEL32_HH(vxb,vxb);
    /* Normalize x to x0*/

    nsaa = AE_NSAZ32_L(vxa);
    nsab = AE_NSAZ32_L(vxb);

    t0 = AE_MOVDA32X2( nsaa, nsab );
    t1 = AE_AND32( t0, c1 );

    shft_a = AE_MOVAD32_H( t1 );
    shft_b = AE_MOVAD32_L( t1 );

    vxa = AE_SLAA32( vxa, shft_a );
    vxb = AE_SLAA32( vxb, shft_b );

    t0 = AE_SRAI32( t0, 1 );
    nsaa = AE_MOVAD32_H( t0 );
    nsab = AE_MOVAD32_L( t0 );

    vxw = AE_SEL32_HL( vxa, vxb );
    zero = AE_EQ32(vxw, vzw);
    inf_ab = AE_LE32(vxw, vzw);

    /*get table indexes*/
    vxa = AE_SRAI32(vxw, 21); 
    vxa = AE_AND32( vxa, c4 ); 
    idxa= AE_MOVAD32_H(vxa); //
    idxb= AE_MOVAD32_L(vxa); //
    
    vxa = AE_L32X2_X((const ae_int32x2 *)sqrt_table, idxa); 
    vxb = AE_L32X2_X((const ae_int32x2 *)sqrt_table, idxb);

    vcw = AE_SEL32_LL(vxa, vxb);//f'(x0)
    vxc = AE_SEL32_HH(vxa, vxb);// f(x0)
    
    /*Calculate dx for first iteration*/  
    vzf = (vxc);//
    vxf = (vxw);
    AE_MULSFP32X2RAS(vxf, vzf, vzf);// 
    /*Calculate y in first iteration*/
    vcf = (vcw);//
    AE_MULAFP32X2RAS(vzf, vcf, vxf);// vzf = y,Q31
    vxf = (vxw);//
    /*Calculate dx for second iteration*/ 
    AE_MULSFP32X2RAS(vxf, vzf, vzf);//
    /*Calculate y in second iteration*/
    vcf = (vcw);//
    AE_MULAFP32X2RAS(vzf, vcf, vxf);// y, Q31

    vxc =  (vzf);//
    vxd = AE_SRAA32(vxc, nsab);
    vxc = AE_SRAA32(vxc, nsaa);//
    vxc = AE_SEL32_HL(vxc, vxd);// put answer for two numbers

    AE_MOVT32X2(vxc, viw, inf_ab);
    AE_MOVT32X2(vxc, vzw, zero);
    AE_S32X2_IP(vxc, py, 8);//
  }
} /* vec_sqrt32x32_fast() */
