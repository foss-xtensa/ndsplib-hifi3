/* ------------------------------------------------------------------------ */
/* Copyright (c) 2021 by Cadence Design Systems, Inc. ALL RIGHTS RESERVED.  */
/* These coded instructions, statements, and computer programs ('Cadence    */
/* Libraries') are the copyrighted works of Cadence Design Systems Inc.     */
/* Cadence IP is licensed for use with Cadence processor cores only and     */
/* must not be used for any other processors and platforms. Your use of the */
/* Cadence Libraries is subject to the terms of the license agreement you   */
/* have entered into with Cadence Design Systems, or a sublicense granted   */
/* to you by a direct Cadence licensee.                                     */
/* ------------------------------------------------------------------------ */
/*  IntegrIT, Ltd.   www.integrIT.com, info@integrIT.com                    */
/*                                                                          */
/* NatureDSP Signal Library                                                 */
/*                                                                          */
/* This library contains copyrighted materials, trade secrets and other     */
/* proprietary information of IntegrIT, Ltd. This software is licensed for  */
/* use with Cadence processor cores only and must not be used for any other */
/* processors and platforms. The license to use these sources was given to  */
/* Cadence, Inc. under Terms and Condition of a Software License Agreement  */
/* between Cadence, Inc. and IntegrIT, Ltd.                                 */
/* ------------------------------------------------------------------------ */
/*          Copyright (C) 2009-2021 IntegrIT, Limited.                      */
/*                      All Rights Reserved.                                */
/* ------------------------------------------------------------------------ */
/*
   NatureDSP Signal Processing Library. FFT part
    Discrete Cosine Transform, Type IV 
    C code optimized for HiFi3
   Integrit, 2006-2017
*/
/* Signal Processing Library API. */
#include "NatureDSP_Signal_fft.h"
#include "common.h"
#include "dct4_twd.h"

/*-------------------------------------------------------------------------
  Discrete Cosine Transform.
  These functions apply DCT (Type II, Type IV) to input.
  Scaling:
      +-----------------------+--------------------------------------+
      |      Function         |           Scaling options            |
      +-----------------------+--------------------------------------+
      |       dct_16x16       |  3 - fixed scaling before each stage |
      |       dct_24x24       |  3 - fixed scaling before each stage |
      |       dct_32x16       |  3 - fixed scaling before each stage |
      |       dct_32x32       |  3 - fixed scaling before each stage |
      |       dct4_24x24      |  3 - fixed scaling before each stage |
      |       dct4_32x16      |  3 - fixed scaling before each stage |
      |       dct4_32x32      |  3 - fixed scaling before each stage |
      +-----------------------+--------------------------------------+
  NOTES:
     1. DCT runs in-place algorithm so INPUT DATA WILL APPEAR DAMAGED after 
     the call.
     2. N - DCT size (depends on selected DCT handle)

  Precision: 
  16x16  16-bit input/outputs, 16-bit twiddles
  24x24  24-bit input/outputs, 24-bit twiddles
  32x16  32-bit input/outputs, 16-bit twiddles
  32x32  32-bit input/outputs, 32-bit twiddles
  f      floating point

  Input:
  x[N]        input signal
  h           DCT handle
  scalingOpt  scaling option (see table above) 
              not applicable to the floating point function
  Output:
  y[N]        transform output
  
  Returned value:
              total number of right shifts occurred during scaling 
              procedure 
  Restriction:
  x,y         should not overlap
  x,y         aligned on 8-bytes boundary
-------------------------------------------------------------------------*/

#define LOG2_SZ_CF24P 4/* log2(2*2*sizeof(f24)) */

static void dct3p(uint64_t *x,uint64_t* y,int N,const tdct4_twd_fr32 *pdct4_twd);
static void ifft_cplx24x24_pair (uint64_t* y,uint64_t* x, const complex_fract32* twd, int N);
static void dct3p_N16(uint64_t *x,uint64_t* y,const tdct4_twd_fr32 *pdct4_twd);

int dct4_24x24( f24 * y,f24 * x,dct_handle_t h,int scalingOpt)
{
          ae_f24x2 * restrict px0;
          ae_f24x2 * restrict px1;
          ae_f24x2 * restrict py0;
          ae_f24x2 * restrict py1;
          ae_f24x2 * restrict py2;
          ae_f24x2 * restrict py3;
    const ae_f24x2 * restrict ptwd0;
    const ae_f24x2 * restrict ptwd1;
    const tdct4_twd_fr32 *ptwd=(const tdct4_twd_fr32 *)h;
    ae_f24x2 X0, X1, Y0, Y1, Y2, Y3;
    ae_f24x2 WV0, WV1, WV2, WV3;
    ae_f24x2 tw0, tw1, tw2, tw3;
    ae_f64 ACC0, ACC1, ACC2, ACC3, ACC4, ACC5, ACC6, ACC7;
    ae_valign al_x0, al_x1, al_y0, al_y1;
    int N,k;

    NASSERT_ALIGN8(x);
    NASSERT_ALIGN8(y);
    NASSERT(scalingOpt == 3);

    N=ptwd->N;

    /*
      Rearrange input data. Even samples are w, odd - v
      N2 = N/2;
      w(1) = x(1);
      v(N2) = x(N);
      for k=1:(N2-1)
        w(k+1) = x(2*k+1) + x(2*k);
        v(k)   = x(2*k)   - x(2*k+1);
      end
    */
    px0 = (ae_f24x2 *)(x);
    px1 = (ae_f24x2 *)(x+N-1);
    py0 = (ae_f24x2 *)(y);
    py1 = (ae_f24x2 *)(y+N-1);
    {
        AE_L32F24_IP(X0, castxcc(ae_f24,px0),       sizeof(f24));
        AE_L32F24_IP(X1, castxcc(ae_f24,px1), -(int)sizeof(f24));
        Y0 = AE_SRAI24(X0, 1);
        Y1 = AE_SRAI24(X1, 1);
        AE_S32F24_L_IP(Y0, castxcc(ae_f24,py0), sizeof(f24));
        AE_S32F24_L_IP(Y1, castxcc(ae_f24,py0), sizeof(f24));

        AE_L32F24_IP(X1, castxcc(ae_f24,px0), sizeof(f24));
        AE_L32F24_IP(X0, castxcc(ae_f24,px0), sizeof(f24));
        X0 = AE_SRAI24(X0, 1);
        X1 = AE_SRAI24(X1, 1);
        Y0 = AE_ADD24S(X0, X1);
        Y1 = AE_SUB24S(X1, X0);
        AE_S32F24_L_IP(Y0, castxcc(ae_f24,py0),  sizeof(int32_t));
        AE_S32F24_L_IP(Y1, castxcc(ae_f24,py1), -(int)sizeof(int32_t));
    }
    al_x0 = AE_LA64_PP(px0);
    al_x1 = AE_LA64_PP(px1);
    al_y0 = AE_ZALIGN64();
    al_y1 = AE_ZALIGN64();
    __Pragma("loop_count min=1");
    for (k=1; k<(N>>2); k++)
    {
        AE_LA32X2F24_IP (X0, al_x0, px0);
        AE_LA32X2F24_RIP(X1, al_x1, px1);

        X0 = AE_SRAI24(X0, 1);
        X1 = AE_SRAI24(X1, 1);
        Y0 = AE_SELP24_LL(X1, X0);
        Y1 = AE_SELP24_HH(X1, X0);
        Y2 = AE_SELP24_LL(X1, X0);
        Y3 = AE_SELP24_HH(X1, X0);

        X0 = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(Y0, Y1));
        X1 = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(Y3, Y2));

        AE_SA32X2F24_IP (X0, al_y0, py0);
        AE_SA32X2F24_RIP(X1, al_y1, py1);
    }
    AE_SA64POS_FP(al_y0, py0);
    AE_SA64NEG_FP(al_y1, py1);

    if (N==32)
    {
        dct3p_N16((uint64_t*)y,(uint64_t*)x,ptwd);
    }
    else
    {
        dct3p((uint64_t*)y,(uint64_t*)x,N>>1,ptwd);
    }

    /* split part */
    ptwd0 = (const ae_f24x2 *)(ptwd->split);
    ptwd1 = (const ae_f24x2 *)(ptwd->split+N/4);
    px0 = (ae_f24x2 *)(x);
    px1 = (ae_f24x2 *)(x+N-2);
    py0 = (ae_f24x2 *)(y      );
    py1 = (ae_f24x2 *)(y+N/2-2);
    py2 = (ae_f24x2 *)(y+N/2  );
    py3 = (ae_f24x2 *)(y+N  -2);
    __Pragma("loop_count min=1");
    for (k=0; k<(N>>3); k++)
    {
        AE_L32X2F24_IP(WV0, px0,       2*sizeof(f24));
        AE_L32X2F24_XP(WV1, px1, -2*(int)sizeof(f24));
        AE_L32X2F24_IP(WV2, px0,       2*sizeof(f24));
        AE_L32X2F24_XP(WV3, px1, -2*(int)sizeof(f24));

        AE_L32X2F24_IP(tw0, ptwd0, 2*sizeof(f24));
        AE_L32X2F24_IP(tw1, ptwd1, 2*sizeof(f24));
        AE_L32X2F24_IP(tw2, ptwd0, 2*sizeof(f24));
        AE_L32X2F24_IP(tw3, ptwd1, 2*sizeof(f24));
        tw2 = AE_SELP24_LH(tw2, tw2);
        tw3 = AE_SELP24_LH(tw3, tw3);

        ACC0 = AE_MULZASFD24_HH_LL(WV0, tw0);
        ACC1 = AE_MULZSSFD24_HL_LH(WV1, tw1);
        ACC2 = AE_MULZASFD24_HH_LL(WV1, tw1);
        ACC3 = AE_MULZSSFD24_HL_LH(WV0, tw0);
        ACC4 = AE_MULZAAFD24_HL_LH(WV2, tw2);
        ACC5 = AE_MULZSAFD24_HH_LL(WV3, tw3);
        ACC6 = AE_MULZAAFD24_HL_LH(WV3, tw3);
        ACC7 = AE_MULZSAFD24_HH_LL(WV2, tw2);
        Y0 = AE_ROUND24X2F48SASYM(ACC0, ACC4);
        Y1 = AE_ROUND24X2F48SASYM(ACC5, ACC1);
        Y2 = AE_ROUND24X2F48SASYM(ACC2, ACC6);
        Y3 = AE_ROUND24X2F48SASYM(ACC7, ACC3);

        AE_S32X2F24_IP(Y0, py0,       2*sizeof(f24));
        AE_S32X2F24_XP(Y1, py1, -2*(int)sizeof(f24));
        AE_S32X2F24_IP(Y2, py2,       2*sizeof(f24));
        AE_S32X2F24_XP(Y3, py3, -2*(int)sizeof(f24));
    }
    return 30-NSA(N);
} /* dct4_24x24() */

/*
    DCT-III on pairs of data
    input:
    x[N]
    Output:
    y[N]
*/
static void dct3p(uint64_t *x,uint64_t* y,int N,const tdct4_twd_fr32* pdct4_twd)
{
          ae_f24x2 * restrict px0;
          ae_f24x2 * restrict px1;
          ae_f24x2 * restrict py0;
          ae_f24x2 * restrict py1;
    const ae_f24x2 * restrict ptwd;
    ae_f24x2 X0, X1, T0, T1, Y0, Y1;
    ae_f24x2 a0re, a0im, b0re, b0im;
    ae_f24x2 a1re, a1im, b1re, b1im;
    ae_f24x2 cs;
    int k;

    px0 = (ae_f24x2 *)x;
    py0 = (ae_f24x2 *)y;

    X0 = ae_f24x2_loadi(px0, 0);
    X1 = ae_f24x2_loadx(px0, (N/2)*sizeof(ae_f24x2));
    X1 = AE_MOVF24X2_FROMF32X2(AE_MULFP24X2RA(X1, AE_MOVF24X2_FROMINT32(AE_MOVDA32(5931642L))));
    Y0 = AE_SELP24_HH(X0, X1);
    Y1 = AE_SELP24_LL(X0, X1);
    ae_f24x2_storeip(Y0,py0,sizeof(ae_f24x2));
    ae_f24x2_storeip(Y1,py0,sizeof(ae_f24x2));

    px0 = (ae_f24x2 *)(x+1);
    px1 = (ae_f24x2 *)(x+N-1);
    ptwd = (const ae_f24x2 *)(pdct4_twd->dct3+1);
    __Pragma("loop_count min=1");
    for (k=1; k<(N>>1); k++)
    {
        AE_L32X2F24_IP(cs, ptwd, sizeof(ae_f24x2));
        cs = AE_SELP24_LH(cs, cs);
        ae_f24x2_loadip(X0, px0,       sizeof(ae_f24x2));
        ae_f24x2_loadxp(X1, px1, -(int)sizeof(ae_f24x2));

        T0 = AE_F24X2_SRAI(X0, 1);
        T1 = AE_F24X2_SRAI(X1, 1);
        X0 = AE_SELP24_HH(T0, T1);
        X1 = AE_SELP24_LL(T0, T1);
        Y0 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(X0, cs));
        Y1 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(X1, cs));

        ae_f24x2_storeip(Y0,py0,sizeof(ae_f24x2));
        ae_f24x2_storeip(Y1,py0,sizeof(ae_f24x2));
    }
    /* real fft (Nyquist sample is packed to the imaginary part of y[]) */
    px0 = (ae_f24x2 *)(x);
    px1 = (ae_f24x2 *)(x+N-1);
    py0 = (ae_f24x2 *)(y);
    py1 = (ae_f24x2 *)(y+N-1);
    ptwd = (const ae_f24x2 *)(pdct4_twd->rfft);
    {
        ae_f24x2_loadip(a0re, py0, sizeof(ae_f24x2));
        ae_f24x2_loadip(a1re, py0, sizeof(ae_f24x2));
        a0re = AE_F24X2_SRAI(a0re, 1);
        a1re = AE_F24X2_SRAI(a1re, 1);
        X0 = AE_SELP24_HH(a0re, a0re);
        Y0 = AE_SELP24_LL(a0re, a0re);
        X1 = AE_SELP24_HH(a1re, a1re);
        Y1 = AE_SELP24_LL(a1re, a1re);
        X0 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(X0, Y0));
        X1 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(X1, Y1));
        ae_f24x2_storeip(X0,px0,sizeof(ae_f24x2));
        ae_f24x2_storeip(X1,px0,sizeof(ae_f24x2));
    }
    __Pragma("loop_count min=1");
    for (k=1; k<(N>>2); k++)
    {
        AE_L32X2F24_IP(cs, ptwd, sizeof(ae_f24x2));
        ae_f24x2_loadip(a0re, py0,       sizeof(ae_f24x2));
        ae_f24x2_loadip(a0im, py0,       sizeof(ae_f24x2));
        ae_f24x2_loadxp(a1im, py1, -(int)sizeof(ae_f24x2));
        ae_f24x2_loadxp(a1re, py1, -(int)sizeof(ae_f24x2));

        a0re = AE_F24X2_SRAI(a0re, 1);
        a0im = AE_F24X2_SRAI(a0im, 1);
        a1re = AE_F24X2_SRAI(a1re, 1);
        a1im = AE_F24X2_SRAI(a1im, 1);
        b0re = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(a0re, a1re));
        b0im = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(a0im, a1im));
        b1re = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(a0re, a1re));
        b1im = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(a0im, a1im));
        Y0 = AE_SELP24_LH(b1re, b1re);
        Y1 = AE_SELP24_LH(b1im, b1im);

        a0re = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(Y0, cs));
        a0im = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(Y1, cs));

        X0 = b0re;
        X1 = b0im;
        Y0 = a0re;
        Y1 = a0im;

        a0re = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(X0, Y0));
        a0im = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(X1, Y1));
        a1re = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(Y0, X0));
        a1im = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(Y1, X1));

        ae_f24x2_storeip(a0re,px0,      sizeof(ae_f24x2));
        ae_f24x2_storeip(a0im,px0,      sizeof(ae_f24x2));
        ae_f24x2_storexp(a1im,px1,-(int)sizeof(ae_f24x2));
        ae_f24x2_storexp(a1re,px1,-(int)sizeof(ae_f24x2));
    }
    {
        X0 = ae_f24x2_loadi(py0, 0);
        X1 = ae_f24x2_loadi(py1, 0);
        T0 = AE_SELP24_HH(X0, X1);
        T0 = AE_NEG24S(T0);
        Y0 = AE_SELP24_HL(T0, X0);
        Y1 = AE_SELP24_LL(T0, X1);
        ae_f24x2_storei(Y0,px0, 0);
        ae_f24x2_storei(Y1,px1, 0);
    }
    /* IFFT and final permutation */
    ifft_cplx24x24_pair (y,x,pdct4_twd->fft, N/2);
    px0 = (ae_f24x2 *)(x);
    px1 = (ae_f24x2 *)(x+N-1);
    py0 = (ae_f24x2 *)(y);
    py1 = (ae_f24x2 *)(y+1);
    __Pragma("loop_count min=1");
    for (k=0; k<(N>>2); k++)
    {
        ae_f24x2_loadip (X0, px0, sizeof(ae_f24x2));
        ae_f24x2_loadip (X1, px0, sizeof(ae_f24x2));
        Y0 = AE_SELP24_LL(X0, X1);
        Y1 = AE_SELP24_HH(X0, X1);
        ae_f24x2_storeip(Y0, py0, 2*sizeof(ae_f24x2));
        ae_f24x2_storeip(Y1, py0, 2*sizeof(ae_f24x2));

        ae_f24x2_loadxp (X0, px1, -(int)sizeof(ae_f24x2));
        ae_f24x2_loadxp (X1, px1, -(int)sizeof(ae_f24x2));
        Y0 = AE_SELP24_HH(X1, X0);
        Y1 = AE_SELP24_LL(X1, X0);
        ae_f24x2_storeip(Y0, py1, 2*sizeof(ae_f24x2));
        ae_f24x2_storeip(Y1, py1, 2*sizeof(ae_f24x2));
    }
}

/*
    paired fft: operates with pairs of data packed in 64-bit words
    input/output:
    x[N]    - data
    Input:
    twd[3/4*N]  - twiddles
    N           - FFT size
    Temporary:
    y[N]
*/
static void ifft_cplx24x24_pair (uint64_t* y,uint64_t* x, const complex_fract32* twd,  int N)
{
          ae_f24x2 * restrict px0;
          ae_f24x2 * restrict px1;
          ae_f24x2 * restrict px2;
          ae_f24x2 * restrict px3;
          ae_f24x2 * restrict py0;
          ae_f24x2 * restrict py1;
          ae_f24x2 * restrict py2;
          ae_f24x2 * restrict py3;
    const ae_f24x2 * restrict ptwd;
    int logN, idx, bitrevstride, stride;
    int m, n;
    int twdstep;

    ae_f24x2 a00, a01, a10, a11, a20, a21, a30, a31;
    ae_f24x2 b00, b01, b10, b11, b20, b21, b30, b31;
    ae_f24x2 tw1, tw2, tw3;

    NASSERT( x );
    NASSERT( y );
    NASSERT( twd );
    NASSERT( x != y );
    NASSERT_ALIGN( x, 8 );
    NASSERT_ALIGN( y, 8 );
    NASSERT( N>=8 && 0 == (N&(N-1)) );

    twdstep = 1;
    logN = 30 - NSA( N );

    /*----------------------------------------------------------------------------*
     * Perform the first stage. We use DIF, all permutations are deferred until   *
     * the last stage.                                                            */
    stride = N/4;
    ptwd = (const ae_f24x2 *)(twd);
    px0 = (ae_f24x2 *)(x+0*2*stride);
    px1 = (ae_f24x2 *)(x+1*2*stride);
    px2 = (ae_f24x2 *)(x+2*2*stride);
    px3 = (ae_f24x2 *)(x+3*2*stride);
    py0 = (ae_f24x2 *)(y+0*2*stride);
    py1 = (ae_f24x2 *)(y+1*2*stride);
    py2 = (ae_f24x2 *)(y+2*2*stride);
    py3 = (ae_f24x2 *)(y+3*2*stride);

    for ( n=0; n<stride; n++ )
    {
        AE_L32X2F24_IP(tw1, ptwd, sizeof(ae_f24x2));
        AE_L32X2F24_IP(tw2, ptwd, sizeof(ae_f24x2));
        AE_L32X2F24_IP(tw3, ptwd, sizeof(ae_f24x2));

        /* Real and imaginary parts are swapped on the first and last stages to
         * inverse the FFT:
         * conj(x) == -j*swap(x) =>
         * ifft(x) == conj(fft(conj(x)) == swap(fft(swap(x)))
         * Just in case, divide data by the FFT size. */
        ae_f24x2_loadip(a01, px0, sizeof(ae_f24x2));
        ae_f24x2_loadip(a00, px0, sizeof(ae_f24x2));
        ae_f24x2_loadip(a11, px1, sizeof(ae_f24x2));
        ae_f24x2_loadip(a10, px1, sizeof(ae_f24x2));
        ae_f24x2_loadip(a21, px2, sizeof(ae_f24x2));
        ae_f24x2_loadip(a20, px2, sizeof(ae_f24x2));
        ae_f24x2_loadip(a31, px3, sizeof(ae_f24x2));
        ae_f24x2_loadip(a30, px3, sizeof(ae_f24x2));
        a00 = AE_F24X2_SRAI(a00, 2);
        a01 = AE_F24X2_SRAI(a01, 2);
        a10 = AE_F24X2_SRAI(a10, 2);
        a11 = AE_F24X2_SRAI(a11, 2);
        a20 = AE_F24X2_SRAI(a20, 2);
        a21 = AE_F24X2_SRAI(a21, 2);
        a30 = AE_F24X2_SRAI(a30, 2);
        a31 = AE_F24X2_SRAI(a31, 2);

        b00 = AE_ADD24S(a00, a20);
        b01 = AE_ADD24S(a01, a21);
        b10 = AE_ADD24S(a10, a30);
        b11 = AE_ADD24S(a11, a31);
        b20 = AE_SUB24S(a00, a20);
        b21 = AE_SUB24S(a01, a21);
        b30 = AE_SUB24S(a10, a30);
        b31 = AE_SUB24S(a11, a31);

        b30 = AE_SELP24_LH(b30, b30);
        b31 = AE_SELP24_LH(b31, b31);
                                                              
        a00 = AE_MOVF24X2_FROMF32X2(AE_ADD32   (b00, b10));
        a01 = AE_MOVF24X2_FROMF32X2(AE_ADD32   (b01, b11));
        a10 = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(b20, b30));
        a11 = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(b21, b31));
        a20 = AE_MOVF24X2_FROMF32X2(AE_SUB32   (b00, b10));
        a21 = AE_MOVF24X2_FROMF32X2(AE_SUB32   (b01, b11));
        a30 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(b20, b30));
        a31 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(b21, b31));

        b00 = a00;
        b01 = a01;
        b10 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a10, tw1));
        b11 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a11, tw1));
        b20 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a20, tw2));
        b21 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a21, tw2));
        b30 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a30, tw3));
        b31 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a31, tw3));

        /* Two middle quartiles are swapped on all but the last stage to use the bit reversal
         * permutation instead of the digit reverse. */
        ae_f24x2_storeip(b00, py0, sizeof(ae_f24x2));
        ae_f24x2_storeip(b01, py0, sizeof(ae_f24x2));
        ae_f24x2_storeip(b20, py1, sizeof(ae_f24x2));
        ae_f24x2_storeip(b21, py1, sizeof(ae_f24x2));
        ae_f24x2_storeip(b10, py2, sizeof(ae_f24x2));
        ae_f24x2_storeip(b11, py2, sizeof(ae_f24x2));
        ae_f24x2_storeip(b30, py3, sizeof(ae_f24x2));
        ae_f24x2_storeip(b31, py3, sizeof(ae_f24x2));
    }

    /*----------------------------------------------
      Perform second through the next to last stages.*/
    for ( stride/=4; stride>1; stride/=4 )
    {
        twdstep *= 4;

        for ( m=0; m*(4*stride)<N; m++ )
        {
            ptwd = (const ae_f24x2 *)(twd);

            px0 = (ae_f24x2 *)(y+4*m*2*stride+0*2*stride);
            px1 = (ae_f24x2 *)(y+4*m*2*stride+1*2*stride);
            px2 = (ae_f24x2 *)(y+4*m*2*stride+2*2*stride);
            px3 = (ae_f24x2 *)(y+4*m*2*stride+3*2*stride);

            py0 = (ae_f24x2 *)(y+4*m*2*stride+0*2*stride);
            py1 = (ae_f24x2 *)(y+4*m*2*stride+1*2*stride);
            py2 = (ae_f24x2 *)(y+4*m*2*stride+2*2*stride);
            py3 = (ae_f24x2 *)(y+4*m*2*stride+3*2*stride);

            __Pragma("loop_count min=1");
            for ( n=0; n<stride; n++ )
            {
                AE_L32X2F24_IP(tw1, ptwd, sizeof(ae_f24x2));
                AE_L32X2F24_IP(tw2, ptwd, sizeof(ae_f24x2));
                AE_L32X2F24_IP(tw3, ptwd, sizeof(ae_f24x2));
                ptwd += twdstep*3-3;

                ae_f24x2_loadip(a00, px0, sizeof(ae_f24x2));
                ae_f24x2_loadip(a01, px0, sizeof(ae_f24x2));
                ae_f24x2_loadip(a10, px1, sizeof(ae_f24x2));
                ae_f24x2_loadip(a11, px1, sizeof(ae_f24x2));
                ae_f24x2_loadip(a20, px2, sizeof(ae_f24x2));
                ae_f24x2_loadip(a21, px2, sizeof(ae_f24x2));
                ae_f24x2_loadip(a30, px3, sizeof(ae_f24x2));
                ae_f24x2_loadip(a31, px3, sizeof(ae_f24x2));
                a00 = AE_F24X2_SRAI(a00, 2);
                a01 = AE_F24X2_SRAI(a01, 2);
                a10 = AE_F24X2_SRAI(a10, 2);
                a11 = AE_F24X2_SRAI(a11, 2);
                a20 = AE_F24X2_SRAI(a20, 2);
                a21 = AE_F24X2_SRAI(a21, 2);
                a30 = AE_F24X2_SRAI(a30, 2);
                a31 = AE_F24X2_SRAI(a31, 2);

                b00 = AE_ADD24S(a00, a20);
                b01 = AE_ADD24S(a01, a21);
                b10 = AE_ADD24S(a10, a30);
                b11 = AE_ADD24S(a11, a31);
                b20 = AE_SUB24S(a00, a20);
                b21 = AE_SUB24S(a01, a21);
                b30 = AE_SUB24S(a10, a30);
                b31 = AE_SUB24S(a11, a31);

                b30 = AE_SELP24_LH(b30, b30);
                b31 = AE_SELP24_LH(b31, b31);

                a00 = AE_MOVF24X2_FROMF32X2(AE_ADD32   (b00, b10));
                a01 = AE_MOVF24X2_FROMF32X2(AE_ADD32   (b01, b11));
                a10 = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(b20, b30));
                a11 = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(b21, b31));
                a20 = AE_MOVF24X2_FROMF32X2(AE_SUB32   (b00, b10));
                a21 = AE_MOVF24X2_FROMF32X2(AE_SUB32   (b01, b11));
                a30 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(b20, b30));
                a31 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(b21, b31));

                b00 = a00;
                b01 = a01;
                b10 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a10, tw1));
                b11 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a11, tw1));
                b20 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a20, tw2));
                b21 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a21, tw2));
                b30 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a30, tw3));
                b31 = AE_MOVF24X2_FROMF32X2(AE_MULFC24RA(a31, tw3));

                /* Two middle quartiles are swapped on all but the last stage to use the bit reversal
                 * permutation instead of the digit reverse. */
                ae_f24x2_storeip(b00, py0, sizeof(ae_f24x2));
                ae_f24x2_storeip(b01, py0, sizeof(ae_f24x2));
                ae_f24x2_storeip(b20, py1, sizeof(ae_f24x2));
                ae_f24x2_storeip(b21, py1, sizeof(ae_f24x2));
                ae_f24x2_storeip(b10, py2, sizeof(ae_f24x2));
                ae_f24x2_storeip(b11, py2, sizeof(ae_f24x2));
                ae_f24x2_storeip(b30, py3, sizeof(ae_f24x2));
                ae_f24x2_storeip(b31, py3, sizeof(ae_f24x2));
            }
        }
    }

    /*----------------------------------------------------------------------------
    Last stage (radix-4 or radix-2 for odd powers of two) with bit reversal
    permutation. */
    idx = 0;
    bitrevstride = 0x80000000U >> (logN-3+LOG2_SZ_CF24P);

    if ( stride == 1 )
    {
        px0 = (ae_f24x2 *)(y+2*0);
        px1 = (ae_f24x2 *)(y+2*1);
        px2 = (ae_f24x2 *)(y+2*2);
        px3 = (ae_f24x2 *)(y+2*3);
        py0 = (ae_f24x2 *)(x+2*0*N/4);
        py1 = (ae_f24x2 *)(x+2*1*N/4);
        py2 = (ae_f24x2 *)(x+2*2*N/4);
        py3 = (ae_f24x2 *)(x+2*3*N/4);
        __Pragma("loop_count min=1");
        for ( n=0; n<(N>>2); n++ )
        {
            ae_f24x2_loadip(a00, px0,   sizeof(ae_f24x2));
            ae_f24x2_loadip(a01, px0, 7*sizeof(ae_f24x2));
            ae_f24x2_loadip(a10, px1,   sizeof(ae_f24x2));
            ae_f24x2_loadip(a11, px1, 7*sizeof(ae_f24x2));
            ae_f24x2_loadip(a20, px2,   sizeof(ae_f24x2));
            ae_f24x2_loadip(a21, px2, 7*sizeof(ae_f24x2));
            ae_f24x2_loadip(a30, px3,   sizeof(ae_f24x2));
            ae_f24x2_loadip(a31, px3, 7*sizeof(ae_f24x2));
            a00 = AE_F24X2_SRAI(a00, 2);
            a01 = AE_F24X2_SRAI(a01, 2);
            a10 = AE_F24X2_SRAI(a10, 2);
            a11 = AE_F24X2_SRAI(a11, 2);
            a20 = AE_F24X2_SRAI(a20, 2);
            a21 = AE_F24X2_SRAI(a21, 2);
            a30 = AE_F24X2_SRAI(a30, 2);
            a31 = AE_F24X2_SRAI(a31, 2);

            b00 = AE_ADD24S(a00, a20);
            b01 = AE_ADD24S(a01, a21);
            b10 = AE_ADD24S(a10, a30);
            b11 = AE_ADD24S(a11, a31);
            b20 = AE_SUB24S(a00, a20);
            b21 = AE_SUB24S(a01, a21);
            b30 = AE_SUB24S(a10, a30);
            b31 = AE_SUB24S(a11, a31);

            b30 = AE_SELP24_LH(b30, b30);
            b31 = AE_SELP24_LH(b31, b31);
                                                              
            a00 = AE_MOVF24X2_FROMF32X2(AE_ADD32   (b00, b10));
            a01 = AE_MOVF24X2_FROMF32X2(AE_ADD32   (b01, b11));
            a10 = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(b20, b30));
            a11 = AE_MOVF24X2_FROMF32X2(AE_ADDSUB32(b21, b31));
            a20 = AE_MOVF24X2_FROMF32X2(AE_SUB32   (b00, b10));
            a21 = AE_MOVF24X2_FROMF32X2(AE_SUB32   (b01, b11));
            a30 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(b20, b30));
            a31 = AE_MOVF24X2_FROMF32X2(AE_SUBADD32(b21, b31));


            /* Real and imaginary parts are swapped on the first and last stages to
             * inverse the FFT:
             * conj(x) == -j*swap(x) =>
             * ifft(x) == conj(fft(conj(x)) == swap(fft(swap(x))) */
            ae_f24x2_storex(a01, py0, idx+0*sizeof(ae_f24x2));
            ae_f24x2_storex(a00, py0, idx+1*sizeof(ae_f24x2));
            ae_f24x2_storex(a11, py1, idx+0*sizeof(ae_f24x2));
            ae_f24x2_storex(a10, py1, idx+1*sizeof(ae_f24x2));
            ae_f24x2_storex(a21, py2, idx+0*sizeof(ae_f24x2));
            ae_f24x2_storex(a20, py2, idx+1*sizeof(ae_f24x2));
            ae_f24x2_storex(a31, py3, idx+0*sizeof(ae_f24x2));
            ae_f24x2_storex(a30, py3, idx+1*sizeof(ae_f24x2));

            idx = AE_ADDBRBA32(idx, bitrevstride);
        }
    }
    else
    {
        bitrevstride >>= 1;

        px0 = (ae_f24x2 *)(y+0);
        px1 = (ae_f24x2 *)(y+1);
        px2 = (ae_f24x2 *)(y+2);
        px3 = (ae_f24x2 *)(y+3);
        py0 = (ae_f24x2 *)(x+0);
        py1 = (ae_f24x2 *)(x+1);
        py2 = (ae_f24x2 *)(x+0+N);
        py3 = (ae_f24x2 *)(x+1+N);
        __Pragma("loop_count min=1");
        for ( n=0; n<(N>>1); n++ )
        {
            ae_f24x2_loadip(a00, px0, 4*sizeof(ae_f24x2));
            ae_f24x2_loadip(a01, px1, 4*sizeof(ae_f24x2));
            ae_f24x2_loadip(a10, px2, 4*sizeof(ae_f24x2));
            ae_f24x2_loadip(a11, px3, 4*sizeof(ae_f24x2));
            a00 = AE_F24X2_SRAI(a00, 1);
            a01 = AE_F24X2_SRAI(a01, 1);
            a10 = AE_F24X2_SRAI(a10, 1);
            a11 = AE_F24X2_SRAI(a11, 1);

            b00 = AE_ADD24S(a00, a10);
            b01 = AE_ADD24S(a01, a11);
            b10 = AE_SUB24S(a00, a10);
            b11 = AE_SUB24S(a01, a11);

            /* Real and imaginary parts are swapped on the first and last stages to
             * inverse the FFT:
             * conj(x) == -j*swap(x) =>
             * ifft(x) == conj(fft(conj(x)) == swap(fft(swap(x))) */
            ae_f24x2_storex(b01, py0, idx);
            ae_f24x2_storex(b00, py1, idx);
            ae_f24x2_storex(b11, py2, idx);
            ae_f24x2_storex(b10, py3, idx);

            idx = AE_ADDBRBA32(idx, bitrevstride);
        }
    }
} /* ifft_cplx24x24_pair() */

/*
    DCT-III on pairs of data, N==16
    input:
    x[N]
    Output:
    y[N]
*/
static void dct3p_N16(uint64_t *x,uint64_t* y,const tdct4_twd_fr32* pdct4_twd)
{
    const int N = 16;
          ae_f24x2 * restrict px0;
          ae_f24x2 * restrict px1;
          ae_f24x2 * restrict px2;
          ae_f24x2 * restrict px3;
          ae_f24x2 * restrict py0;
          ae_f24x2 * restrict py1;
          ae_f24x2 * restrict py2;
          ae_f24x2 * restrict py3;
    const ae_f24x2 * restrict ptwd0;
    const ae_f24x2 * restrict ptwd1;
    const ae_f24x2 * restrict ptwd2;
    ae_f24x2 X0, X1, T0, T1, Y0, Y1;
    ae_f24x2 a0re, a0im, b0re, b0im;
    ae_f24x2 a1re, a1im, b1re, b1im;
    ae_f24x2 cs;
    int k;

    px0 = (ae_f24x2 *)(x);
    px1 = (ae_f24x2 *)(x+N-1);
    px2 = (ae_f24x2 *)(x+N/2-1);
    px3 = (ae_f24x2 *)(x+N/2+1);
    py0 = (ae_f24x2 *)(y);
    py1 = (ae_f24x2 *)(y+N-1);
    ptwd0 = (const ae_f24x2 *)(pdct4_twd->dct3+1);
    ptwd1 = (const ae_f24x2 *)(pdct4_twd->dct3+7);
    ptwd2 = (const ae_f24x2 *)(pdct4_twd->rfft);

    {
        X1 = ae_f24x2_loadx(px0, (N/2)*sizeof(ae_f24x2));
        ae_f24x2_loadip(X0, px0, sizeof(ae_f24x2));
        X1 = AE_MOVF24X2_FROMF32X2(AE_MULFP24X2RA(X1, AE_MOVF24X2_FROMINT32(AE_MOVDA32(5931642L))));

        a0re = AE_F24X2_SRAI(X0, 1);
        a1re = AE_F24X2_SRAI(X1, 1);
        X0 = AE_ADD24S(a0re, a1re);
        X1 = AE_SUB24S(a0re, a1re);
        Y0 = AE_SELP24_HH(X1, X0);
        Y1 = AE_SELP24_LL(X1, X0);

        ae_f24x2_storeip(Y0,py0,sizeof(ae_f24x2));
        ae_f24x2_storeip(Y1,py0,sizeof(ae_f24x2));
    }
    for (k=1; k<N/4; k++)
    {
        AE_L32X2F24_IP(cs, ptwd0, sizeof(ae_f24x2));
        cs = AE_SELP24_LH(cs, cs);
        ae_f24x2_loadip(X0, px0,       sizeof(ae_f24x2));
        ae_f24x2_loadxp(X1, px1, -(int)sizeof(ae_f24x2));

        T0 = AE_F24X2_SRAI(X0, 1);
        T1 = AE_F24X2_SRAI(X1, 1);
        X0 = AE_SELP24_HH(T0, T1);
        X1 = AE_SELP24_LL(T0, T1);
        a0re = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(X0, cs));
        a0im = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(X1, cs));

        AE_L32X2F24_XP(cs, ptwd1, -(int)sizeof(ae_f24x2));
        cs = AE_SELP24_LH(cs, cs);
        ae_f24x2_loadxp(X0, px2, -(int)sizeof(ae_f24x2));
        ae_f24x2_loadip(X1, px3,       sizeof(ae_f24x2));

        T0 = AE_F24X2_SRAI(X0, 1);
        T1 = AE_F24X2_SRAI(X1, 1);
        X0 = AE_SELP24_HH(T0, T1);
        X1 = AE_SELP24_LL(T0, T1);
        a1re = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(X0, cs));
        a1im = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(X1, cs));

        AE_L32X2F24_IP(cs, ptwd2, sizeof(ae_f24x2));
        a0re = AE_F24X2_SRAI(a0re, 1);
        a0im = AE_F24X2_SRAI(a0im, 1);
        a1re = AE_F24X2_SRAI(a1re, 1);
        a1im = AE_F24X2_SRAI(a1im, 1);

        b0re = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(a0re, a1re));
        b0im = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(a0im, a1im));
        b1re = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(a0re, a1re));
        b1im = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(a0im, a1im));
        Y0 = AE_SELP24_LH(b1re, b1re);
        Y1 = AE_SELP24_LH(b1im, b1im);
        a0re = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(Y0, cs));
        a0im = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(Y1, cs));

        X0 = b0re;
        X1 = b0im;
        Y0 = a0re;
        Y1 = a0im;

        a0re = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(X0, Y0));
        a0im = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(X1, Y1));
        a1re = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(Y0, X0));
        a1im = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(Y1, X1));

        ae_f24x2_storeip(a0re,py0,      sizeof(ae_f24x2));
        ae_f24x2_storeip(a0im,py0,      sizeof(ae_f24x2));
        ae_f24x2_storexp(a1im,py1,-(int)sizeof(ae_f24x2));
        ae_f24x2_storexp(a1re,py1,-(int)sizeof(ae_f24x2));
    }
    {
        AE_L32X2F24_XP(cs, ptwd1, -(int)sizeof(ae_f24x2));
        ae_f24x2_loadxp(X0, px2, -(int)sizeof(ae_f24x2));
        ae_f24x2_loadip(X1, px3,       sizeof(ae_f24x2));
        T0 = AE_F24X2_SRAI(X0, 1);
        T1 = AE_F24X2_SRAI(X1, 1);
        X0 = AE_SELP24_HH(T1, T0);
        X1 = AE_SELP24_LL(T1, T0);
        Y0 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(X0, cs));
        Y1 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(X1, cs));

        ae_f24x2_storexp(Y1,py1,-(int)sizeof(ae_f24x2));
        ae_f24x2_storexp(Y0,py1,-(int)sizeof(ae_f24x2));
    }
    __Pragma("no_reorder");
    /* IFFT (on pairs of data, N=8) and final permutation */
    {
        int stride;
        int n;

        ae_f24x2 a00, a01, a10, a11, a20, a21, a30, a31;
        ae_f24x2 b00, b01, b10, b11, b20, b21, b30, b31;
        ae_f24x2 tw1, tw2, tw3;

        /*----------------------------------------------------------------------------*
         * Perform the first stage. We use DIF, all permutations are deferred until   *
         * the last stage.                                                            */
        stride = 8/4;
        ptwd0 = (const ae_f24x2 *)(pdct4_twd->fft);
        px0 = (ae_f24x2 *)(y+0*2*stride);
        px1 = (ae_f24x2 *)(y+1*2*stride);
        px2 = (ae_f24x2 *)(y+2*2*stride);
        px3 = (ae_f24x2 *)(y+3*2*stride);
        py0 = (ae_f24x2 *)(x+0*2*stride);
        py1 = (ae_f24x2 *)(x+1*2*stride);
        py2 = (ae_f24x2 *)(x+2*2*stride);
        py3 = (ae_f24x2 *)(x+3*2*stride);

        for ( n=0; n<stride; n++ )
        {
            AE_L32X2F24_IP(tw1, ptwd0, sizeof(ae_f24x2));
            AE_L32X2F24_IP(tw2, ptwd0, sizeof(ae_f24x2));
            AE_L32X2F24_IP(tw3, ptwd0, sizeof(ae_f24x2));

            /* Real and imaginary parts are swapped on the first and last stages to
             * inverse the FFT:
             * conj(x) == -j*swap(x) =>
             * ifft(x) == conj(fft(conj(x)) == swap(fft(swap(x)))
             * Just in case, divide data by the FFT size. */
            ae_f24x2_loadip(a01, px0, sizeof(ae_f24x2));
            ae_f24x2_loadip(a00, px0, sizeof(ae_f24x2));
            ae_f24x2_loadip(a11, px1, sizeof(ae_f24x2));
            ae_f24x2_loadip(a10, px1, sizeof(ae_f24x2));
            ae_f24x2_loadip(a21, px2, sizeof(ae_f24x2));
            ae_f24x2_loadip(a20, px2, sizeof(ae_f24x2));
            ae_f24x2_loadip(a31, px3, sizeof(ae_f24x2));
            ae_f24x2_loadip(a30, px3, sizeof(ae_f24x2));
            a00 = AE_F24X2_SRAI(a00, 2);
            a01 = AE_F24X2_SRAI(a01, 2);
            a10 = AE_F24X2_SRAI(a10, 2);
            a11 = AE_F24X2_SRAI(a11, 2);
            a20 = AE_F24X2_SRAI(a20, 2);
            a21 = AE_F24X2_SRAI(a21, 2);
            a30 = AE_F24X2_SRAI(a30, 2);
            a31 = AE_F24X2_SRAI(a31, 2);

            b00 = AE_ADD24S(a00, a20);
            b01 = AE_ADD24S(a01, a21);
            b10 = AE_ADD24S(a10, a30);
            b11 = AE_ADD24S(a11, a31);
            b20 = AE_SUB24S(a00, a20);
            b21 = AE_SUB24S(a01, a21);
            b30 = AE_SUB24S(a10, a30);
            b31 = AE_SUB24S(a11, a31);

            b30 = AE_SELP24_LH(b30, b30);
            b31 = AE_SELP24_LH(b31, b31);
                                                              
            a00 = AE_ADD24S(b00, b10);
            a01 = AE_ADD24S(b01, b11);
            a10 = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(b20, b30));
            a11 = AE_MOVF24X2_FROMINT32X2(AE_ADDSUB32(b21, b31));
            a20 = AE_SUB24S(b00, b10);
            a21 = AE_SUB24S(b01, b11);
            a30 = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(b20, b30));
            a31 = AE_MOVF24X2_FROMINT32X2(AE_SUBADD32(b21, b31));

            b00 = a00;
            b01 = a01;
            b10 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(a10, tw1));
            b11 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(a11, tw1));
            b20 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(a20, tw2));
            b21 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(a21, tw2));
            b30 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(a30, tw3));
            b31 = AE_MOVF24X2_FROMINT32X2(AE_MULFC24RA(a31, tw3));

            /* Two middle quartiles are swapped on all but the last stage to use the bit reversal
             * permutation instead of the digit reverse. */
            ae_f24x2_storeip(b00, py0, sizeof(ae_f24x2));
            ae_f24x2_storeip(b01, py0, sizeof(ae_f24x2));
            ae_f24x2_storeip(b20, py1, sizeof(ae_f24x2));
            ae_f24x2_storeip(b21, py1, sizeof(ae_f24x2));
            ae_f24x2_storeip(b10, py2, sizeof(ae_f24x2));
            ae_f24x2_storeip(b11, py2, sizeof(ae_f24x2));
            ae_f24x2_storeip(b30, py3, sizeof(ae_f24x2));
            ae_f24x2_storeip(b31, py3, sizeof(ae_f24x2));
        }

        __Pragma("no_reorder");
        /*-------------------------------------------------------------------
          Last stage (radix-2) with bit reversal permutation.
          Final DCT-3 algorithm permutation is combined with FFT permutation.
        -------------------------------------------------------------------*/
        {
            px0 = (ae_f24x2 *)(x+0);
            px1 = (ae_f24x2 *)(x+1);
            px2 = (ae_f24x2 *)(x+2);
            px3 = (ae_f24x2 *)(x+3);
            py0 = (ae_f24x2 *)(y+0);
            py1 = (ae_f24x2 *)(y+1);

            /* Real and imaginary parts are swapped on the first and last stages to
             * inverse the FFT:
             * conj(x) == -j*swap(x) =>
             * ifft(x) == conj(fft(conj(x)) == swap(fft(swap(x))) */
            {
                ae_f24x2_loadip(a00, px0, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a01, px1, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a10, px2, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a11, px3, 4*sizeof(ae_f24x2));
                a00 = AE_F24X2_SRAI(a00, 1);
                a01 = AE_F24X2_SRAI(a01, 1);
                a10 = AE_F24X2_SRAI(a10, 1);
                a11 = AE_F24X2_SRAI(a11, 1);

                b00 = AE_ADD24S(a00, a10);
                b01 = AE_ADD24S(a01, a11);
                b10 = AE_SUB24S(a00, a10);
                b11 = AE_SUB24S(a01, a11);

                a00 = AE_SELP24_HH(b01, b00);
                a01 = AE_SELP24_LL(b01, b00);
                a10 = AE_SELP24_HH(b11, b10);
                a11 = AE_SELP24_LL(b11, b10);
                ae_f24x2_storex(a01, py0, 0*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a00, py0, 1*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a11, py1, 7*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a10, py1, 6*2*sizeof(ae_f24x2));
            }
            {
                ae_f24x2_loadip(a00, px0, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a01, px1, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a10, px2, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a11, px3, 4*sizeof(ae_f24x2));
                a00 = AE_F24X2_SRAI(a00, 1);
                a01 = AE_F24X2_SRAI(a01, 1);
                a10 = AE_F24X2_SRAI(a10, 1);
                a11 = AE_F24X2_SRAI(a11, 1);

                b00 = AE_ADD24S(a00, a10);
                b01 = AE_ADD24S(a01, a11);
                b10 = AE_SUB24S(a00, a10);
                b11 = AE_SUB24S(a01, a11);

                a00 = AE_SELP24_HH(b01, b00);
                a01 = AE_SELP24_LL(b01, b00);
                a10 = AE_SELP24_HH(b11, b10);
                a11 = AE_SELP24_LL(b11, b10);
                ae_f24x2_storex(a01, py0, 4*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a00, py0, 5*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a11, py1, 3*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a10, py1, 2*2*sizeof(ae_f24x2));
            }
            {
                ae_f24x2_loadip(a00, px0, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a01, px1, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a10, px2, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a11, px3, 4*sizeof(ae_f24x2));
                a00 = AE_F24X2_SRAI(a00, 1);
                a01 = AE_F24X2_SRAI(a01, 1);
                a10 = AE_F24X2_SRAI(a10, 1);
                a11 = AE_F24X2_SRAI(a11, 1);

                b00 = AE_ADD24S(a00, a10);
                b01 = AE_ADD24S(a01, a11);
                b10 = AE_SUB24S(a00, a10);
                b11 = AE_SUB24S(a01, a11);

                a00 = AE_SELP24_HH(b01, b00);
                a01 = AE_SELP24_LL(b01, b00);
                a10 = AE_SELP24_HH(b11, b10);
                a11 = AE_SELP24_LL(b11, b10);
                ae_f24x2_storex(a01, py0, 2*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a00, py0, 3*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a11, py1, 5*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a10, py1, 4*2*sizeof(ae_f24x2));
            }
            {
                ae_f24x2_loadip(a00, px0, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a01, px1, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a10, px2, 4*sizeof(ae_f24x2));
                ae_f24x2_loadip(a11, px3, 4*sizeof(ae_f24x2));
                a00 = AE_F24X2_SRAI(a00, 1);
                a01 = AE_F24X2_SRAI(a01, 1);
                a10 = AE_F24X2_SRAI(a10, 1);
                a11 = AE_F24X2_SRAI(a11, 1);

                b00 = AE_ADD24S(a00, a10);
                b01 = AE_ADD24S(a01, a11);
                b10 = AE_SUB24S(a00, a10);
                b11 = AE_SUB24S(a01, a11);

                a00 = AE_SELP24_HH(b01, b00);
                a01 = AE_SELP24_LL(b01, b00);
                a10 = AE_SELP24_HH(b11, b10);
                a11 = AE_SELP24_LL(b11, b10);
                ae_f24x2_storex(a01, py0, 6*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a00, py0, 7*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a11, py1, 1*2*sizeof(ae_f24x2));
                ae_f24x2_storex(a10, py1, 0*2*sizeof(ae_f24x2));
            }
        }
    } /* IFFT with permutation */
}
